项目是一个恋爱模拟器，旨在帮助当代青年大胆说爱。
使用方法
conda create -n xunfei python=3.10
conda activate xunfei


python app.py
